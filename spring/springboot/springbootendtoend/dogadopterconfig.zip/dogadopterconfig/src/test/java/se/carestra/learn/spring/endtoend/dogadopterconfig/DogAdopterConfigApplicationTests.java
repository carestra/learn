package se.carestra.learn.spring.endtoend.dogadopterconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogAdopterConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
