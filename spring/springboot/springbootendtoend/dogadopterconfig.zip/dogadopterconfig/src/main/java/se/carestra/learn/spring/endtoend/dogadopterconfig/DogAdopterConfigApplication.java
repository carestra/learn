package se.carestra.learn.spring.endtoend.dogadopterconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogAdopterConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogAdopterConfigApplication.class, args);
	}

}
