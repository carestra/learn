package se.carestra.learn.spring.endtoend.dogadopterbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DogAdopterBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
