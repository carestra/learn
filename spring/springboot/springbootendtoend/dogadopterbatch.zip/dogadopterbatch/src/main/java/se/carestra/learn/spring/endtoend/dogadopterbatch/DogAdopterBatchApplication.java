package se.carestra.learn.spring.endtoend.dogadopterbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DogAdopterBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(DogAdopterBatchApplication.class, args);
	}

}
