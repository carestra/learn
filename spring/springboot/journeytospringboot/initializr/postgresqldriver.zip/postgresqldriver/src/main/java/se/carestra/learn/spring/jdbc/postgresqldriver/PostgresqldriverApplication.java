package se.carestra.learn.spring.jdbc.postgresqldriver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostgresqldriverApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostgresqldriverApplication.class, args);
	}

}
