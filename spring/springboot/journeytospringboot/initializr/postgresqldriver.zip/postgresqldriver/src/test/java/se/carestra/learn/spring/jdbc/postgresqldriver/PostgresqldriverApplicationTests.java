package se.carestra.learn.spring.jdbc.postgresqldriver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgresqldriverApplicationTests {

	@Test
	void contextLoads() {
	}

}
